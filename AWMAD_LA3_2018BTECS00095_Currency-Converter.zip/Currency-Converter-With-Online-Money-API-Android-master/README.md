# Currency-Converter-With-Online-Money-API-Android
This is an demo application of currency converter android application This application works with real time online money API. From this project you will learn how to use Android Spinner, Nested JSON Parsing with Volley,Applying TextWatcher in EditText, Text Text to speech with Google TTS and lot more...

### Download the app (build version) from APK folder

# USD-TO-BDT && USD-TO-INR <br/>
![Alt text](Screenshot/USD2BDT.PNG?raw=true "USD2BDT")
![Alt text](Screenshot/USD2INR.PNG?raw=true "USD2INR") <br/>

# Android-Spinner <br/>
![Alt text](Screenshot/OptionChose.PNG?raw=true "OptionChose")
![Alt text](Screenshot/OptionChose2.PNG?raw=true "OptionChose2") <br/>

# BDT-TO-INR <br/>
![Alt text](Screenshot/BDT2INR.PNG?raw=true "BDT2INR") <br/>
